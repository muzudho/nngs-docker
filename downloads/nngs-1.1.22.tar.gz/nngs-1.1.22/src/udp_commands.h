#ifndef UDP_COMMANDS_H
#define UDP_COMMANDS_H 1
int udp_command(char *dst, size_t dstlen, char * src);
#endif
