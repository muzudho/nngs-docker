#ifndef MAILER_H
#define MAILER_H

int mail_spool(char *nbuff, const char *to, const char *subj, const char *text, const char *fname);

#endif
