/* cpuid2cpuflags -- AT_HWCAP* routine prototypes
 * (c) 2015-2019 Michał Górny
 * 2-clause BSD licensed
 */

unsigned long get_hwcap();
unsigned long get_hwcap2();
char* get_uname_machine();
